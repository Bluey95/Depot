Compass-Boilerplate
===================

Boilerplate folders and files to start using Sass and Compass.

This repo is used as a guide for [How to start using Sass and Compass in 10 minutes](http://www.gayadesign.com/diy/how-to-start-using-sass-and-compass-in-10-minutes/)